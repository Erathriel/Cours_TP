//
// Created by Antoine on 15/09/2017.
//


#include <stdio.h>
#include "fa.h"

int main (int argc, char *argv[]) {
    struct fa test;
    fa_create(&test,2, 4);
    return 0;
}
