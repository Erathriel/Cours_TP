#include <stddef.h>
#include <stdlib.h>
#include "fa.h"

//
// Created by Antoine on 15/09/2017.
//
void fa_create(struct fa *self, size_t alpha_count, size_t state_count) {
    self->alpha_count = alpha_count;
    self->state_count = state_count;
    self->states = calloc(state_count,sizeof(struct state));
    self->transitions=calloc(state_count, sizeof(struct state_set));
    for(int i=0; i<state_count;i++){
        self->transitions[i]=calloc(alpha_count, sizeof(struct state_set));
    }

};

void fa_destroy(struct fa *self) {
    free(self);
};

void fa_set_state_initial(struct fa *self, size_t state) {
    self->states[state].is_initial=true;
}

void fa_set_state_final(struct fa *self, size_t state){
    self->states[state].is_final=true;
}

